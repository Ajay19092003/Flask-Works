from flask import Flask, request, jsonify, render_template
import pickle
import pandas as pd

app = Flask(__name__)

# Load the recommendation model
with open('recommendation_model.pkl', 'rb') as f:
    model_data = pickle.load(f)

cosine_sim = model_data['cosine_sim']
vectorizer = model_data['vectorizer']
movies = model_data['movies']

# Define the recommendation function
def get_recommendations(title, cosine_sim):
    idx = movies[movies['movie_title'] == title].index[0]
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:6]
    movie_indices = [i[0] for i in sim_scores]
    return movies.iloc[movie_indices]['movie_title'].tolist()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/recommend', methods=['POST'])
def recommend():
    movie_title = request.form['movie_title']
    if movie_title in movies['movie_title'].values:
        recommendations = get_recommendations(movie_title, cosine_sim)
        return jsonify({'recommended_movies': recommendations})
    else:
        return jsonify({'error': 'Movie not found in the database!'})

if __name__ == "__main__":
    app.run(debug=True)
