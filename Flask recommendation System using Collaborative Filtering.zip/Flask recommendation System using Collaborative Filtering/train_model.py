import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pickle

# Sample movie dataset
data = {
    'movie_title': ['Movie A', 'Movie B', 'Movie C', 'Movie D', 'Movie E'],
    'movie_description': [
        'Action and adventure',
        'Romantic comedy',
        'Sci-fi thriller',
        'Horror and suspense',
        'Documentary about nature'
    ]
}

movies = pd.DataFrame(data)

# Generate TF-IDF matrix
vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform(movies['movie_description'])

# Compute cosine similarity
cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

# Save the model as a pickle file
model_data = {
    'cosine_sim': cosine_sim,
    'vectorizer': vectorizer,
    'movies': movies
}

with open('static/model/recommendation_model.pkl', 'wb') as f:
    pickle.dump(model_data, f)

    pickle.dump(model_data, f)