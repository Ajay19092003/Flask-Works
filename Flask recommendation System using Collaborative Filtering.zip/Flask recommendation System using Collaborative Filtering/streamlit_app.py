import streamlit as st
import pickle
import pandas as pd

# Load the recommendation model
with open('recommendation_model.pkl', 'rb') as f:
    model_data = pickle.load(f)

cosine_sim = model_data['cosine_sim']
vectorizer = model_data['vectorizer']
movies = model_data['movies']

# Define the recommendation function
def get_recommendations(title, cosine_sim):
    idx = movies[movies['movie_title'] == title].index[0]
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:6]
    movie_indices = [i[0] for i in sim_scores]
    return movies.iloc[movie_indices]['movie_title'].tolist()

# Streamlit app
st.title("Movie Recommendation System")

movie_title = st.text_input("Enter a movie title:")

if st.button("Get Recommendations"):
    if movie_title in movies['movie_title'].values:
        recommendations = get_recommendations(movie_title, cosine_sim)
        st.write("Recommended movies:", recommendations)
    else:
        st.write("Movie not found in the database!")
